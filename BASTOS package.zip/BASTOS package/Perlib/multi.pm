

package phase;

BEGIN {
	$VERSION = '1.0';
}


use strict;
use Getopt::Long;
use base 'Exporter';
our @EXPORT = qw(runphase);

my $G_USAGE = "
$0 phase --Pbam <P bam file> --Mbam <M bam file> --Hbam <H bam file> --Lbam <L bam file>  --genome <reference>  --prefix <outputPrefix> --phase2 <T/F>

          --Pbam <P bam file>
          --Mbam <M bam file>
          --Hbam <H bam file>
          --Lbam <L bam file>
          --genome <reference genome>
          --phase2 <T/F> phasing two heterzyous site using two local-phasing strategy; default: F; please note if T, this step is very slow
          --oprefix  <outputPrefix>



";

sub runphase {
	my $Pbam = undef;
 	my $Mbam = undef;
        my $Hbam = undef;
        my $Lbam = undef;
        my $genome = undef;
	my $outputPrefix = undef;
	my $help = 0;
	
	GetOptions (
	"Pbam=s" => \$Pbam,
	"Mbam=s" => \$Mbam,
        "Hbam=s" => \$Hbam,
        "Lbam=s" => \$Lbam,
        "genome=s" => \$genome,
	"oprefix=s"   => \$outputPrefix,
	"help!" => \$help)
	or die("Error in command line arguments\n$G_USAGE");
	
	die "$G_USAGE" if ($help);
	
	die "Please specify the output prefix\n$G_USAGE" if (!defined $outputPrefix);
   
         my $samtools= "$FindBin::Bin/software/samtools";
         my $bwa="$FindBin::Bin/software/bwa";
         my $gg="$FindBin::Bin/scripts/filter_get_genotype.pl";

         my $get_ref="$FindBin::Bin/scripts/get_refer.pl";
         my $get_block="$FindBin::Bin/scripts/get_block.pl";

         my $P_phase=$Pbam."_phase";
         my $M_phase=$Mbam."_phase";
         my $H_phase=$Hbam."_phase";
         my $L_phase=$Lbam."_phase";
         my $P_ref =$Pbam."_ref";
         my $M_ref =$Mbam."_ref";
         my $H_ref =$Hbam."_ref";
         my $L_ref= $Lbam."_ref";
         my $P_bl =$Pbam."_block";
         my $M_bl =$Mbam."_block";
         my $H_bl =$Hbam."_block";
         my $L_bl= $Lbam."_block";
         
       

        my $script = $outputPrefix."_sh";
   
        open (my $ofh, ">$script") or die $!;
          
                 
         print $ofh "$samtools phase $Pbam >$P_phase\n";
         print $ofh "$samtools phase $Mbam >$M_phase\n";
         print $ofh "$samtools phase $Hbam >$H_phase\n";
         print $ofh "$samtools phase $Lbam >$L_phase\n";
         print $ofh "$get_ref  $P_phase $genome >$P_ref\n";
         print $ofh "$get_ref  $M_phase $genome >$M_ref\n";
         print $ofh "$get_ref  $H_phase $genome >$H_ref\n";
         print $ofh "$get_ref  $L_phase $genome >$L_ref\n";
         print $ofh "$get_block  $P_ref $P_phase >$P_bl\n";
         print $ofh "$get_block  $M_ref $M_phase >$M_bl\n";
         print $ofh "$get_block  $H_ref $H_phase >$H_bl\n";
         print $ofh "$get_block  $L_ref $L_phase >$L_bl\n";

         close $ofh;
         &process_cmd("sh $script");
         exit(0);
 
              }


    sub process_cmd {
    my ($cmd) = @_;
    print STDERR "CMD: $cmd\n";
    my $ret = system($cmd);
    if ($ret) {
        die "Error, cmd: $cmd died with ret $ret";
    }

    return;
                  }

 

   sub local_phase {


   



    
             
                   }	

  sub cmp_phase{
      
               }
 
  sub merge_hp{
           
             }
