#!/usr/bin/Rscript
 
   argv<-commandArgs(TRUE);
   load(file=argv[1]);
   sub<-data[data$pos >=argv[2] & data$pos <= argv[3],];
   max<-sub[which.max(sub$Gp),];   
    max$Gp;
    max$pos;



   
