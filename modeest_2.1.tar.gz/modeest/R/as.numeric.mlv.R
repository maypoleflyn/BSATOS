

as.numeric.mlv <-
function(x,
         ...)
{
  return(x$M)
}
