#!/usr/bin/perl 

  use warnings;
  use strict;
   my @a; 
   open LOD,"<$ARGV[0]";
 while(<LOD>){
      chomp;
     @a=split/\t/,$_;
   if($a[0] eq $ARGV[1] && ($a[1] >= $ARGV[2]) && ($a[1] <=$ARGV[3])){
           print "$_\t$ARGV[2]\t$ARGV[3]\t$ARGV[4]\n";
       }
       }  
  
